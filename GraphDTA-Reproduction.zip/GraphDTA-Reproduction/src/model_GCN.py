import torch
from torch_geometric.nn import GCNConv, global_max_pool

class GraphDTA_GCN(torch.nn.Module):
    def __init__(self, num_node_features, hidden_channels=128):
        super(GraphDTA_GCN, self).__init__()
        self.conv1 = GCNConv(num_node_features, hidden_channels)
        self.conv2 = GCNConv(hidden_channels, hidden_channels)
        self.fc1 = torch.nn.Linear(hidden_channels, 512)
        self.fc2 = torch.nn.Linear(512, 1)

    def forward(self, x, edge_index, batch):
        x = self.conv1(x, edge_index).relu()
        x = self.conv2(x, edge_index).relu()
        x = global_max_pool(x, batch)
        x = torch.nn.functional.relu(self.fc1(x))
        return self.fc2(x)
