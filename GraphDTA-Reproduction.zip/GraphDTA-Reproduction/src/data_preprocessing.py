from rdkit import Chem
from rdkit.Chem import rdmolops
import torch

def smiles_to_graph(smiles):
    mol = Chem.MolFromSmiles(smiles)
    atom_features = [atom.GetAtomicNum() for atom in mol.GetAtoms()]
    adj = rdmolops.GetAdjacencyMatrix(mol)
    return torch.tensor(atom_features, dtype=torch.float), torch.tensor(adj, dtype=torch.float)
