import numpy as np

def concordance_index(y_true, y_pred):
    pairs = [(i, j) for i in range(len(y_true)) for j in range(i+1, len(y_true))]
    n, s = 0, 0
    for i, j in pairs:
        if y_true[i] != y_true[j]:
            n += 1
            if (y_pred[i] < y_pred[j] and y_true[i] < y_true[j]) or (y_pred[i] > y_pred[j] and y_true[i] > y_true[j]):
                s += 1
            elif y_pred[i] == y_pred[j]:
                s += 0.5
    return s / n if n > 0 else 0
